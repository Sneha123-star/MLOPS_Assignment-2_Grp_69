this is readme file.

Predicted results will be shown as:

IF quality is >=0 then LOW else HIGH